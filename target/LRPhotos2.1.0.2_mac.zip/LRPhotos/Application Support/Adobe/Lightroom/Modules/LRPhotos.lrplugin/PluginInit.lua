PluginInit = {
	pluginID = "at.homebrew.lrphotos",
}
